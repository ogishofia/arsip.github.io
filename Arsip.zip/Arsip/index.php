<!DOCTYPE html>
<html>
<head>
  <title>ARSIP</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
</head>
<body>
  <header class="site-headers">
    <nav>
      <div class="logo">
        <!-- <h1>ARSIP AUDIO VISUAL</h1> -->
      </div>
    </nav>

    <section>
      <div class="leftside" style="margin-left: 20px">
        <img src="images/dinas.jpeg">
      </div>
      <div class="rightside">
        <h1>DINAS KEARSIPAN KABUPATEN WONOGIRI</h1>
        <p>Klik Tombol Login untuk Masuk</p>
        <button onclick="location.href='login.php'">login</button>
      </div>
    </section>
  </header>
</body>
</html>